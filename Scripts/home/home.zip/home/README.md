The zip file in this directory contains all of the other files
in this directory.  If you tell GitHub to show you the zip
file it will tell you that it can't, but it will offer you a
Download button.  Touch the Download button to download the zip
file.  Then you can extract the files that are packaged inside
it and have your own local copies of the files in this directory
without having to download the whole repository.  If you would
like to download your own copy of the whole repository you can
go to the top directory in the repository and use the Clone or
Download button and GitHub will send you a zip file of the whole
repository.
